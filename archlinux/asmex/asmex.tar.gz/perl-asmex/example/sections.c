__attribute__ ((section(".foo"))) int f(int a, int b)
{
	return a +b;
}

__attribute__ ((section(".bar"))) int g(int a, int b)
{
	return a +b;
}
