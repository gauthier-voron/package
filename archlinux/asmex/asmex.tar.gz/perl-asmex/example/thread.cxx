#include <cstdio>

// #include <metasys/sched/Thread.hxx>

#include <pthread.h>
#include <unistd.h>


// using metasys::Thread;



void task()
{
	// while (true)
	::sleep(1);
}

static void *__task_wrapper(void *)
{
	task();
	return NULL;
}


class Thread
{
	pthread_t  _tid;


	void _stop()
	{
		_tid = -1;
	}


 public:
	constexpr Thread() noexcept
		: _tid(-1)
	{
	}

	explicit constexpr Thread(pthread_t tid) noexcept
		: _tid(tid)
	{
	}

	Thread(const Thread &) = delete;

	Thread(Thread &&other) noexcept
		: _tid(other._tid)
	{
		other._tid = -1;
	}

	~Thread()
	{
		_stop();
	}

	Thread &operator=(const Thread &) = delete;

	Thread &operator=(Thread &&other) noexcept
	{
		if (valid()) {
			if (other._tid != _tid) [[likely]]
				_stop();
		}

		_tid = other._tid;
		other._tid = -1;

		return *this;
	}


	constexpr bool valid() const noexcept
	{
		return (_tid != -1);
	}


	static void *__wrapper_task(void *task)
	{
		((void (*)()) task)();
		return NULL;
	}

	template<void (*Task)()>
	static void *__wrapper(void *)
	{
		Task();
		return NULL;
	}

	template<void (*Task)()>
	void create()
	{
		pthread_create(&_tid, NULL, &__wrapper<Task>, NULL);
	}

	void join()
	{
		pthread_join(_tid, NULL);
	}
};


int main()
{
	// pthread_t tid;
	// pthread_create(&tid, NULL, &__task_wrapper, NULL);
	// pthread_join(tid, NULL);


	Thread thread;
	thread.create<task>();
	thread.join();


	// pthread_t tid;
	// pthread_create(&tid, NULL, &__task_wrapper, NULL);
	// Thread thread = Thread(tid);
	// thread.join();


	return 0;
}
