package Asmex::Object;

use strict;
use warnings;

use base qw(Exporter);

use constant {
    CODE_ADDR => 0,
    CODE_BIN  => 1,
    CODE_ASM  => 2,

    SUBPROG_NAME   => 0,
    SUBPROG_LNAME  => 1,
    SUBPROG_FINDEX => 2,
    SUBPROG_LNUM   => 3,
    SUBPROG_ORIG   => 4,

    DLINE_FILE   => 0,
    DLINE_LNUM   => 1,
    DLINE_COLUMN => 2,
    DLINE_STMT   => 3,
    DLINE_DISCR  => 4,
    };


our @EXPORT = (
    'CODE_ADDR', 'CODE_BIN', 'CODE_ASM',
    'DLINE_FILE', 'DLINE_LNUM', 'DLINE_COLUMN', 'DLINE_STMT', 'DLINE_DISCR'
    );


sub new
{
    my ($class, $path) = @_;
    my $self = bless({}, $class);

    return $self->_parse($path)
}

sub _parse
{
    my ($self, $path) = @_;
    my $ret;

    $ret = $self->_parse_code($path);
    if (!defined($ret)) {
	return undef;
    }

    $ret = $self->_parse_compdir($path);
    if (!defined($ret)) {
	return undef;
    }

    $ret = $self->_parse_symbols($path);
    if (!defined($ret)) {
	return undef;
    }

    $ret = $self->_parse_info($path);
    if (!defined($ret)) {
	return undef;
    }

    $ret = $self->_parse_lines($path);
    if (!defined($ret)) {
	return undef;
    }

    $self->_match_sections();

    return $self;
}

sub _parse_code
{
    my ($self, $path) = @_;
    my ($fh, $line, $section, $entry, $addr, $bin, $asm, $type, $symbol);
    my (@sections, $code);
    my @command = ('objdump', '-dCr', $path);

    if (!open($fh, '-|', @command)) {
	return undef;
    }

    while (defined($line = <$fh>)) {
	chomp($line);

	if ($line =~ m|^\s*([0-9a-f]+):\s+([0-9a-f]{2}(?: [0-9a-f]{2})*)(?:\s+(.*\S))?\s*$|) {
	    ($addr, $bin, $asm) = ($1, $2, $3);
	    $addr = hex('0x' . $addr);
	    push(@{$code->{$section}->{$entry}}, [ $addr, $bin, $asm ]);
	    next;
	}

	if ($line =~ m|^\s*([0-9[a-f]+):\s+(R_.*\S)\s+(.*\S)\s*$|) {
	    ($addr, $type, $symbol) = ($1, $2, $3);
	    $symbol =~ s|-0x[0-9a-f]+$||;
	    $code->{$section}->{$entry}->[-1]->[CODE_ASM]
		=~ s|<.*>\s*$|<$symbol>|;
	    next;
	}

	if ($line =~ m|^([0-9a-f]+) <(.*)>:\s*$|) {
	    ($addr, $entry) = ($1, $2);
	    next;
	}

	if ($line =~ m|^\s*$|) {
	    next;
	}

	if ($line =~ m|^Disassembly of section (.*):\s*$|) {
	    $section = $1;
	    push(@sections, $section);
	    next;
	}

	if ($line =~ m|^(.*):\s+file format (.*\S)\s*$|) {
	    # ($file, $format) = ($1, $2);
	    next;
	}

	printf(STDERR "Unknown line: %s\n", $line);
    }

    close($fh);

    $self->{_sections} = \@sections;
    $self->{_code} = $code;

    return $self;
}

sub _parse_compdir
{
    my ($self, $path) = @_;
    my ($fh, $line, $dir);
    my @command = ('objdump', '--dwarf=info', $path);

    if (!open($fh, '-|', @command)) {
	return undef;
    }

    while (defined($line = <$fh>)) {
	chomp($line);

	if ($line =~ m|DW_AT_comp_dir.*: (/.*)$|) {
	    $dir = $1;
	    last;
	}
    }

    close($fh);

    $self->{_compdir} = $dir;

    return $self;
}

sub _parse_symbols
{
    my ($self, $path) = @_;
    my ($table, $fh, $line, $addr, $section, $size, $end, $symbol);
    my @command = ('objdump', '--syms', $path);

    if (!open($fh, '-|', @command)) {
	return undef;
    }

    while (defined($line = <$fh>)) {
	chomp($line);

	if ($line =~ m|^([0-9a-f]+) .{7} (\S+)\s+([0-9a-f]+)\s+(.*)$|) {
	    ($addr, $section, $size, $symbol) = ($1, $2, $3, $4);
	    $addr = hex('0x' . $addr);
	    $end = $addr + hex('0x' . $size);
	    push(@{$table->{$section}->{$addr}}, [ $symbol, $end ]);
	    next;
	}

	if ($line eq '') {
	    next;
	}

	if ($line eq 'SYMBOL TABLE:') {
	    next;
	}

	if ($line =~ m|^.*\S:\s+file format .*$|) {
	    next;
	}

	printf(STDERR "Unknown line: %s\n", $line);
    }

    close($fh);

    $self->{_symbols} = $table;

    return $self;
}

sub _parse_info
{
    my ($self, $path) = @_;
    my ($table, $fh, $line, $tag, $subprogs, $id);
    my ($name, $lname, $findex, $ln, $orig);
    my @command = ('objdump', '--dwarf=info', $path);

    if (!open($fh, '-|', @command)) {
	return undef;
    }

    $tag = '';

    while (defined($line = <$fh>)) {
	chomp($line);

	if ($line =~ m|<([0-9a-f]+)>:\s*.*\(DW_TAG_(.*)\)$|) {
	    if (defined($id)) {
		$subprogs->{$id} = [ $name, $lname, $findex, $ln, $orig ];
	    }

	    ($id, $tag) = ($1, $2);
	    $name = undef;
	    $lname = undef;
	    $findex = undef;
	    $ln = undef;
	    $orig = undef;

	    next;
	}

	if ($tag ne 'subprogram') {
	    next;
	}

	if ($line =~ m|DW_AT(_linkage)?_name\s*:(?:\s*\(indirect string.*?\):)?\s+(.*)$|){
	    if (defined($1)) {
		$lname = $2;
	    } else {
		$name = $2;
	    }
	    next;
	}

	if ($line =~ m|DW_AT_abstract_origin\s*:\s+<0x([0-9a-f]+)>$|) {
	    $orig = $1;
	    next;
	}

	if ($line =~ m|DW_AT_decl_file\s*:\s+(\d+)$|) {
	    $findex = $1;
	    next;
	}

    	if ($line =~ m|DW_AT_decl_line\s*:\s+(\d+)$|) {
	    $ln = $1;
	    next;
	}
    }

    if (defined($id)) {
	$subprogs->{$id} = [ $name, $lname, $findex, $ln, $orig ];
    }

    foreach $id (keys(%$subprogs)) {
	$name = $subprogs->{$id}->[SUBPROG_LNAME];

	if (!defined($name)) {
	    $name = $subprogs->{$id}->[SUBPROG_NAME];
	}

	if (!defined($name)) {
	    next;
	}

	$findex = $subprogs->{$id}->[SUBPROG_FINDEX];
	$ln = $subprogs->{$id}->[SUBPROG_LNUM];

	if (defined($findex) && defined($ln)) {
	    $table->{$name} = [ $findex, $ln ];
	    next;
	}

	$orig = $subprogs->{$id}->[SUBPROG_ORIG];

	if (!defined($orig)) {
	    next;
	}

	$findex = $subprogs->{$orig}->[SUBPROG_FINDEX];
	$ln = $subprogs->{$orig}->[SUBPROG_LNUM];

	if (defined($findex) && defined($ln)) {
	    $table->{$name} = [ $findex, $ln ];
	    next;
	}
    }

    close($fh);

    $self->{_info} = $table;

    return $self;
}

sub _parse_lines
{
    my ($self, $path) = @_;
    my ($dtable, $ftable, $fh, $line, $dindex, $findex, $dir, $file, $inst);
    my ($table, $sequence, $addr, $dfile, $ln, $column, $stmt, $discr);
    my @command = ('objdump', '--dwarf=rawline', $path);

    if (!open($fh, '-|', @command)) {
	return undef;
    }

    $discr = 0;

    while (defined($line = <$fh>)) {
	chomp($line);

	if ($line =~ m|^\s+\[0x[0-9a-f]+\]\s+(.*)$|) {
	    $inst = $1;

	    if ($inst =~ m|^Set column to (\d+)$|) {
		$column = $1;
		next;
	    }

	    if ($inst =~ m|^Extended opcode 2: set Address to 0x([0-9a-f]+)$|) {
		$addr = hex('0x' . $1);
		next;
	    }

	    if ($inst =~ m|^Advance Line by -?\d+ to (\d+)$|) {
		$ln = $1;
		next;
	    }

	    if ($inst =~ m|^Special opcode \d+: advance Address by \d+ to 0x([0-9a-f]+) and Line by -?\d+ to (\d+)(?: \(view \d+\))?$|) {
		($addr, $ln) = ($1, $2);
		$addr = hex('0x' . $addr);
		push(@{$sequence->{$addr}}, [$dfile, $ln, $column, $stmt, $discr]);
		$discr = 0;
		next;
	    }

	    if ($inst =~ m|^Copy(?: \(view \d+\))?$|) {
		push(@{$sequence->{$addr}}, [$dfile, $ln, $column, $stmt, $discr]);
		$discr = 0;
		next;
	    }

	    if ($inst =~ m|^Set is_stmt to (\d+)$|) {
		$stmt = $1;
		next;
	    }

	    if ($inst =~ m|^Advance PC by -?\d+ to 0x([0-9a-f]+)$|) {
		$addr = hex('0x' . $1);
		next;
	    }

	    if ($inst =~ m|^Advance PC by constant -?\d+ to 0x([0-9a-f]+)$|) {
		$addr = hex('0x' . $1);
		next;
	    }

	    if ($inst =~ m|^Extended opcode \d+: set Discriminator to (\d+)$|) {
		$discr = $1;
		next;
	    }

	    if ($inst =~ m|^Set File Name to entry (\d+) in the File Name Table$|) {
		$dfile = $ftable->{$1};
		next;
	    }

	    if ($inst =~ m|^Extended opcode \d+: End of Sequence$|) {
		push(@{$sequence->{$addr}}, [$dfile, $ln, $column, $stmt, $discr]);
		push(@$table, $sequence);
		$sequence = {};
		$dfile = $ftable->{1};
		$addr = 0;
		$ln = 1;
		$column = 0;
		$discr = 0;
		next;
	    }

	    printf(STDERR "Unknown instruction: %s\n", $inst);
	    next;
	}

	if ($line =~ m|^\s+(\d+)\s+(\d+)(?:\s+\d+){2}\s+(.*)$|) {
	    ($findex, $dindex, $file) = ($1, $2, $3);

	    if ($dindex != 0) {
		$file = $dtable->{$dindex} . '/' . $file;
	    }

	    $ftable->{$findex} = $file;

	    if ($findex == 1) {
		$dfile = $ftable->{1};
	    }

	    next;
	}

	if ($line =~ m|^\s+(\d+)\s+(.*)$|) {
	    ($dindex, $dir) = ($1, $2);
	    $dtable->{$dindex} = $dir;
	    next;
	}

	if ($line =~ m|^\s+Initial value of 'is_stmt':\s+(\d)$|) {
	    $stmt = $1;
	    next;
	}

	if ($line =~ m|^\s+Opcode.*$|) {
	    next;
	} elsif ($line =~ m/^\s+.*:\s+-?(?:0x[0-9a-f]+|\d+)$/) {
	    next;
	} elsif ($line =~ m|^\s+The .* Table \(offset .*\):$|) {
	    next;
	} elsif ($line =~ m|^\s+Line Number Statements:$|) {
	    next;
	} elsif ($line =~ m|^\s+Entry\s+Dir\s+Time\s+Size\s+Name$|) {
	    next;
	} elsif($line eq 'Raw dump of debug contents of section .debug_line:'){
	    next;
	} elsif ($line =~ m|^.*\S:\s+file format .*$|) {
	    next;
	} elsif ($line =~ m|^\s+No Line Number Statements.$|) {
	    next;
	} elsif ($line eq '') {
	    next;
	}

	printf(STDERR "Unknown line: %s\n", $line);
    }

    close($fh);

    $self->{_lines} = $table;

    $self->_update_info($ftable);

    return $self;
}

sub _update_info
{
    my ($self, $ftable) = @_;
    my ($info, $name, $findex, $file);

    $info = $self->{_info};

    foreach $name (keys(%$info)) {
	$findex = $info->{$name}->[0];
	$file = $ftable->{$findex};
	$info->{$name}->[0] = $file;
    }
}


sub _get_section_bounds
{
    my ($self, $section) = @_;
    my ($min, $max, $entry, $start, $end, $bin);

    foreach $entry (keys(%{$self->{_code}->{$section}})) {
	$start = $self->{_code}->{$section}->{$entry}->[0]->[CODE_ADDR];
	$end = $self->{_code}->{$section}->{$entry}->[-1]->[CODE_ADDR];
	$bin = $self->{_code}->{$section}->{$entry}->[-1]->[CODE_BIN];
	$bin =~ s/ //g;
	$end += length($bin) / 2;

	if (!defined($min) || ($start < $min)) {
	    $min = $start;
	}

	if (!defined($max) || ($end > $max)) {
	    $max = $end;
	}
    }

    return [ $min, $max ];
}

sub _filter_sections_by_size
{
    my ($self, $matching) = @_;
    my ($section, %secbounds, $start, $end);
    my ($index, $sequence, @addrs);

    foreach $section (keys(%{$self->{_code}})) {
	($start, $end) = @{$self->_get_section_bounds($section)};
	$secbounds{$section} = [ $start, $end ];
    }

    $index = 0;

    foreach $sequence (@{$self->{_lines}}) {
	@addrs = sort { $a <=> $b } keys(%$sequence);
	$start = $addrs[0];
	$end = $addrs[-1];

	foreach $section (keys(%{$matching->[$index]})) {
	    if ($start < $secbounds{$section}->[0]) {
		delete($matching->[$index]->{$section});
		next;
	    }

	    if ($end > $secbounds{$section}->[1]) {
		delete($matching->[$index]->{$section});
		next;
	    }
	}

	$index += 1;
    }
}

sub _filter_sections_by_overlap
{
    my ($self, $matching) = @_;
    my ($index, $sequence, $section, @addrs, $start, $end);
    my (%reservation, $rstart, $rend, $overlap);

    do {
	$overlap = 0;

	$index = 0;

	foreach $sequence (@{$self->{_lines}}) {
	    if (scalar(%{$matching->[$index]}) != 1) {
		$index += 1;
		next;
	    }

	    $section = (keys(%{$matching->[$index]}))[0];
	    @addrs = sort { $a <=> $b } keys(%$sequence);
	    $start = $addrs[0];
	    $end = $addrs[-1];

	    $reservation{$section}->{$start} = $end;

	    $index += 1;
	}

	$index = 0;

	foreach $sequence (@{$self->{_lines}}) {
	    if (scalar(%{$matching->[$index]}) <= 1) {
		$index += 1;
		next;
	    }

	    @addrs = sort { $a <=> $b } keys(%$sequence);
	    $start = $addrs[0];
	    $end = $addrs[-1];

	    foreach $section (keys(%{$matching->[$index]})) {
		foreach $rstart (keys(%{$reservation{$section}})) {
		    $rend = $reservation{$section}->{$rstart};

		    if ((($start >= $rstart) && ($start <= $rend)) ||
			(($end >= $rstart) && ($end <= $rend)) ||
			(($start < $rstart) && ($end > $rend))) {

			$overlap = 1;
			delete($matching->[$index]->{$section});
			last;
		    }
		}
	    }

	    $index += 1;
	}
    } while ($overlap == 1);
}

sub _filter_sections_by_addr_align
{
    my ($self, $matching) = @_;
    my ($index, $sequence, $addr, $section, %secaddrs, $entry, $inst);
    my (@addrs, @allowed, $last, $miss);

    $index = 0;

    foreach $sequence (@{$self->{_lines}}) {
	if (scalar(%{$matching->[$index]}) <= 1) {
	    $index += 1;
	    next;
	}

	foreach $section (keys(%{$matching->[$index]})) {
	    if (!defined($secaddrs{$section})) {
		foreach $entry (keys(%{$self->{_code}->{$section}})) {
		    foreach $inst (@{$self->{_code}->{$section}->{$entry}}) {
			$secaddrs{$section}->{$inst->[CODE_ADDR]} = 1;
		    }
		}
	    }

	    $miss = 0;
	    @addrs = sort { $a <=> $b } keys(%$sequence);
	    @allowed = sort { $a <=> $b } keys(%{$secaddrs{$section}});

	    # There can be a debug_line for the address right after the end of
	    # the section.
	    if ($addrs[-1] > $allowed[-1]) {
		pop(@addrs);
	    }

	    foreach $addr (@addrs) {
		if (!defined($secaddrs{$section}->{$addr})) {
		    $miss += 1;
		    last;
		}
	    }

	    if ($miss > 0) {
		delete($matching->[$index]->{$section});
	    }
	}

	$index += 1;
    }
}

sub _filter_sections_by_symbol
{
    my ($self, $matching) = @_;
    my ($index, $sequence, $section, $addr, $symbol, $end, $info, $file, $ln);
    my ($insts, $inst, $ifile, $iln, $dist, $numdist, $sumdist, $avgdist);
    my ($dists, %seqdists, $pair);

    $index = 0;

    foreach $sequence (@{$self->{_lines}}) {
	if (scalar(%{$matching->[$index]}) <= 1) {
	    $index += 1;
	    next;
	}

	foreach $section (keys(%{$matching->[$index]})) {
	    $dists = [];

	    foreach $addr (keys(%{$self->{_symbols}->{$section}})) {
		foreach $pair (@{$self->{_symbols}->{$section}->{$addr}}) {
		    ($symbol, $end) = @$pair;

		    $info = $self->{_info}->{$symbol};
		    if (!defined($info)) {
			next;
		    }

		    ($file, $ln) = @$info;

		    $numdist = 0;
		    $sumdist = 0;
		    $insts = $self->{_lines}->[$index]->{$addr};

		    foreach $inst (@$insts) {
			($ifile, $iln) = @$inst;

			if (($ifile ne $file) || ($iln < $ln)) {
			    next;
			}

			$dist = $iln - $ln;
			$numdist += 1;
			$sumdist += $dist;
		    }

		    if ($numdist > 0) {
			$avgdist = $sumdist / $numdist;
			push(@$dists, $avgdist);
		    }
		}
	    }

	    if (scalar(@$dists) > 0) {
		$seqdists{$index}->{$section} = $dists;
	    }
	}

	if (defined($seqdists{$index})) {
	    foreach $section (keys(%{$matching->[$index]})) {
		if (!defined($seqdists{$index}->{$section})) {
		    delete($matching->[$index]->{$section});
		}
	    }
	}

	$index += 1;
    }
}

sub _try_complete_matching
{
    my ($self, $matching) = @_;
    my ($index, $sequence, @addrs, $start, $end, $section);
    my ($table);

    $index = 0;

    foreach $sequence (@{$self->{_lines}}) {
	@addrs = sort { $a <=> $b } keys(%$sequence);
	$start = $addrs[0];
	$end = $addrs[-1];

	foreach $section (keys(%{$matching->[$index]})) {
	    push(@{$table->{$section}->{$start}}, [ $sequence, $end ]);
	}

	$index += 1;
    }

    foreach $section (keys(%$table)) {
	$end = -1;

	foreach $start (sort { $a <=> $b } keys(%{$table->{$section}})) {
	    if (scalar(@{$table->{$section}->{$start}}) > 1) {
		return 0;
	    }

	    if ($start <= $end) {
		return 0;
	    }

	    $end = $table->{$section}->{$start}->[0]->[1];
	    $table->{$section}->{$start} = $table->{$section}->{$start}->[0];
	}
    }

    $self->{_matching} = $table;

    return 1;
}

sub _complete_matching_best_effort
{
    my ($self, $matching) = @_;
    my ($index, $sequence, @addrs, $start, $end, $section);
    my ($table, $ostart, $oend, $conflicts, $cstart, $cend);

    $index = 0;

    foreach $sequence (@{$self->{_lines}}) {
	@addrs = sort { $a <=> $b } keys(%$sequence);
	$start = $addrs[0];
	$end = $addrs[-1];

	foreach $section (keys(%{$matching->[$index]})) {
	    $conflicts = 0;
	    $oend = -1;

	    foreach $ostart (sort { $a <=> $b } keys(%{$table->{$section}})) {
		$oend = $table->{$section}->{$ostart}->[1];

		if ((($start >= $ostart) && ($start <= $oend)) ||
		    (($end >= $ostart) && ($end <= $oend)) ||
		    (($start < $ostart) && ($end > $oend))) {
		    $conflicts += 1;

		    $cstart = $ostart;
		    $cend = $oend;

		    if ($conflicts > 1) {
			last;
		    }
		}
	    }

	    if ($conflicts > 1) {
		next;
	    }

	    if ($conflicts == 1) {
		if (($end - $start) > ($cend - $cstart)) {
		    delete($table->{$section}->{$cstart});
		} else {
		    next;
		}
	    }

	    $table->{$section}->{$start} = [ $sequence, $end ];
	}

	$index += 1;
    }

    $self->{_matching} = $table;
}

sub _trim_identical_sequences
{
    my ($self) = @_;
    my ($len, $i, $j, $iseq, $jseq, $diff, $addr, $iinsts, $jinsts, $k, $e);
    my (%sieve);

    $len = scalar(@{$self->{_lines}});

    for ($i = 1; $i < $len; $i++) {
	$iseq = $self->{_lines}->[$i];

	for ($j = 0; $j < $i; $j++) {
	    if (defined($sieve{$j})) {
		next;
	    }

	    $jseq = $self->{_lines}->[$j];

	    if (scalar(%$jseq) != scalar(%$iseq)) {
		next;
	    }

	    $diff = 0;

	    foreach $addr (keys(%$iseq)) {
		if (!defined($jseq->{$addr})) {
		    $diff = 1;
		    last;
		}

		$iinsts = $iseq->{$addr};
		$jinsts = $jseq->{$addr};

		if (scalar(@$iinsts) != scalar(@$jinsts)) {
		    $diff = 1;
		    last;
		}

		for ($k = 0; $k < scalar(@$iinsts); $k++) {
		    for ($e = 0; $e < scalar(@{$iinsts->[$k]}); $e++) {
			if ($iinsts->[$k]->[$e] ne $jinsts->[$k]->[$e]) {
			    $diff = 1;
			    last;
			}
		    }
		}
	    }

	    if ($diff == 1) {
		next;
	    }

	    $sieve{$i} = $j;
	    last;
	}
    }

    return \%sieve;
}

sub _match_sections
{
    my ($self) = @_;
    my ($sieve, $index, $sequence, $section, @matching);

    $sieve = $self->_trim_identical_sequences();

    $index = 0;

    foreach $sequence (@{$self->{_lines}}) {
	push(@matching, {});

	if (!defined($sieve->{$index})) {
	    foreach $section (keys(%{$self->{_code}})) {
		$matching[-1]->{$section} = 1;
	    }
	}

	$index += 1;
    }

    $self->_filter_sections_by_size(\@matching);

    if ($self->_try_complete_matching(\@matching)) {
	return $self;
    }

    $self->_filter_sections_by_overlap(\@matching);

    if ($self->_try_complete_matching(\@matching)) {
	return $self;
    }

    $self->_filter_sections_by_addr_align(\@matching);

    if ($self->_try_complete_matching(\@matching)) {
	return $self;
    }

    $self->_filter_sections_by_symbol(\@matching);

    if ($self->_try_complete_matching(\@matching)) {
	return $self;
    }

    $self->_filter_sections_by_overlap(\@matching);

    if ($self->_try_complete_matching(\@matching)) {
	return $self;
    }

    $self->_complete_matching_best_effort(\@matching);

    return $self;
}




sub sections
{
    my ($self) = @_;

    return [ @{$self->{_sections}} ];
}

sub entries
{
    my ($self, $section) = @_;
    my $section_code = $self->{_code}->{$section};

    if (!defined($section_code)) {
	return undef;
    }

    return [ sort { $section_code->{$a}->[0]->[CODE_ADDR] <=>
	            $section_code->{$b}->[0]->[CODE_ADDR] }
	     keys(%$section_code) ];
}

sub code
{
    my ($self, $section, $entry) = @_;
    my ($section_code, $entry_code, $line, @ret);

    $section_code = $self->{_code}->{$section};
    if (!defined($section_code)) {
	return undef;
    }

    $entry_code = $section_code->{$entry};
    if (!defined($entry_code)) {
	return undef;
    }

    foreach $line (@$entry_code) {
	push(@ret, [ @$line ]);
    }

    return \@ret;
}

sub lines
{
    my ($self, $section, $addr) = @_;
    my ($entry, $start, $sequence, $end, $ret);

    $entry = $self->{_matching}->{$section};

    foreach $start (sort { $a <=> $b } keys(%$entry)) {
	if ($start > $addr) {
	    return undef;
	}

	($sequence, $end) = @{$entry->{$start}};

	if ($end < $addr) {
	    next;
	}

	$ret = $sequence->{$addr};

	if (defined($ret)) {
	    return [ @$ret ];
	} else {
	    return undef;
	}
    }

    return undef;
}

sub compdir
{
    my ($self) = @_;

    return $self->{_compdir};
}


1;
__END__
